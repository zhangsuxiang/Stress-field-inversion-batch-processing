%% StressInverseBatch.m
% 批量读取 Data 文件夹下所有 .txt/.xls/.xlsx 文件，并对每个文件执行 Vavrycuk 迭代应力反演
% 脚本可以放在任意子目录，会自动定位上一级的 Data/Output/Figures 文件夹

clearvars; close all; clc;

%%----------------------%
% 定位脚本路径并构造 Data/Output/Figures 目录 %
%%----------------------%
scriptFullPath = mfilename('fullpath');
[scriptDir, ~, ~] = fileparts(scriptFullPath);
parentDir    = fileparts(scriptDir);

dataDir  = fullfile(parentDir, 'Data');
outputDir= fullfile(parentDir, 'Output');
figsDir  = fullfile(parentDir, 'Figures');

%%----------------------%
% 不变的控制参数       %
%%----------------------%
N_noise_realizations = 100;
mean_deviation       = 5;    % focal mechanisms 噪声标准差 (°)
N_iterations         = 6;
N_realizations       = 10;
shape_ratio_axis     = 0:0.025:1;
friction_min  = 0.40;
friction_max  = 1.00;
friction_step = 0.05;

%%----------------------%
% 批量读取 Excel/Text 文件 %
%%----------------------%
filesXLSX = dir(fullfile(dataDir, '*.xlsx'));
filesXLS  = dir(fullfile(dataDir, '*.xls'));
filesTXT  = dir(fullfile(dataDir, '*.txt'));
files     = [filesXLSX; filesXLS; filesTXT];

for k = 1:numel(files)
    %% 输入/输出路径构造
    [~, name, ext] = fileparts(files(k).name);
    input_file = fullfile(dataDir, files(k).name);
    outBase    = fullfile(outputDir, name);
    
    % 图文件前缀
    shape_ratio_plot = fullfile(figsDir, [name '_shape_ratio']);
    stress_plot      = fullfile(figsDir, [name '_stress_directions']);
    P_T_plot         = fullfile(figsDir, [name '_P_T_axes']);
    Mohr_plot        = fullfile(figsDir, [name '_Mohr_circles']);
    
    principal_mech_file = [outBase '_principal_mechanisms'];

    %% 读取 focal mechanisms (含第二节面)
    [strike_orig_1, dip_orig_1, rake_orig_1, strike_orig_2, dip_orig_2, rake_orig_2] = ...
        read_mechanisms(input_file);

    %% --- 无噪声数据反演 ---
    [tau_optimum, shape_ratio, strike, dip, rake, ~, friction] = ...
        stress_inversion(strike_orig_1, dip_orig_1, rake_orig_1, ...
                         strike_orig_2, dip_orig_2, rake_orig_2, ...
                         friction_min, friction_max, friction_step, ...
                         N_iterations, N_realizations);

    %% --- 计算主应力轴和主节面 ---
    [V, D] = eig(tau_optimum);
    [~, j] = sort([D(1,1); D(2,2); D(3,3)]);
    sigma1_opt = V(:, j(1));
    sigma3_opt = V(:, j(3));
    [dir1, dir2, dir3] = azimuth_plunge(tau_optimum);
    [ps_str, ps_dip, ps_rake] = principal_mechanisms(sigma1_opt, sigma3_opt, friction);

    %% --- 噪声统计 ---
    % 预分配
    sigma1_stats = zeros(3, N_noise_realizations);
    sigma2_stats = zeros(3, N_noise_realizations);
    sigma3_stats = zeros(3, N_noise_realizations);
    shape_stats  = zeros(N_noise_realizations,1);

    for i = 1:N_noise_realizations
        [s1n, d1n, r1n, s2n, d2n, r2n, n_err, u_err] = ...
            noisy_mechanisms(mean_deviation, strike_orig_1, dip_orig_1, rake_orig_1);
        [sv1, sv2, sv3, srn] = statistics_stress_inversion(...
            s1n, d1n, r1n, s2n, d2n, r2n, friction, N_iterations, N_realizations);
        sigma1_stats(:,i) = sv1;
        sigma2_stats(:,i) = sv2;
        sigma3_stats(:,i) = sv3;
        shape_stats(i)    = srn;
    end

    %% --- 误差计算 ---
    sigma_1_err = acos(abs(sigma1_stats' * sigma1_opt)) * 180/pi;
    sigma_2_err = acos(abs(sigma2_stats' * sigma1_opt)) * 180/pi;
    sigma_3_err = acos(abs(sigma3_stats' * sigma1_opt)) * 180/pi;
    shape_err   = 100 * abs((shape_ratio - shape_stats) / shape_ratio);

    %% --- 保存结果 ---
    sigma_1.azimuth = dir1(1); sigma_1.plunge = dir1(2);
    sigma_2.azimuth = dir2(1); sigma_2.plunge = dir2(2);
    sigma_3.azimuth = dir3(1); sigma_3.plunge = dir3(2);
    mech_data       = [strike, dip, rake];
    principal_data  = [ps_str, ps_dip, ps_rake];

    save([outBase '.mat'], 'sigma_1','sigma_2','sigma_3','shape_ratio', ...
         'mech_data','friction','principal_data');
    save([outBase '.dat'], 'mech_data', '-ASCII');
    save([principal_mech_file '.dat'], 'principal_data', '-ASCII');

    %% --- 绘图 ---
    plot_stress(tau_optimum, strike, dip, rake, P_T_plot);
    plot_mohr(tau_optimum, strike, dip, rake, ps_str, ps_dip, ps_rake, Mohr_plot);
    plot_stress_axes(sigma1_stats, sigma2_stats, sigma3_stats, stress_plot);

    figure; hold on; title('Shape ratio','FontSize',14);
    hist(shape_stats, shape_ratio_axis); box on; grid on;
    saveas(gcf, shape_ratio_plot, 'png');
end