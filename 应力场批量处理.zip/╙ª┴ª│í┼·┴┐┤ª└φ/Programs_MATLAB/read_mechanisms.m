%*************************************************************************%
%                                                                         %
%   function READ_MECHANISMS.m                                            %
%                                                                         %
%   reading the input focal mechansisms                                   %
%                                                                         %
%   now supports both .txt and Excel files                                %
%                                                                         %
%   input: name of the input file                                         %
%                                                                         %
%*************************************************************************%
function [strike1,dip1,rake1,strike2,dip2,rake2] = read_mechanisms(input_file)

    % determine file extension
    [~,~,ext] = fileparts(input_file);
    ext = lower(ext);

    %% --------------------------------------------------------------------
    %  reading raw data (either text or Excel)
    %% --------------------------------------------------------------------
    switch ext
        case '.txt'
            % original behavior: read three columns of numbers
            [strike, dip, rake] = textread(input_file, '%f%f%f', 'commentstyle', 'matlab');

        case {'.xls', '.xlsx'}
            % new behavior: read Excel, take columns 3–5
            M = readmatrix(input_file);
            if size(M,2) < 5
                error('Excel file %s does not have at least 5 columns.', input_file);
            end
            strike = M(:,3);
            dip    = M(:,4);
            rake   = M(:,5);

        otherwise
            error('Unsupported file extension: %s', ext);
    end

    %% --------------------------------------------------------------------
    %  eliminate badly conditioned focal mechanisms
    %% --------------------------------------------------------------------
    % avoid exactly zero dip
    dip_zero = (dip < 1e-5);
    dip = dip + dip_zero * 1e-2;

    % avoid exactly ±90° rake
    rake_90 = (abs(rake) > 89.9999 & abs(rake) < 90.0001);
    rake = rake + rake_90 * 1e-2;

    %% --------------------------------------------------------------------
    %  compute conjugate (second) plane solutions
    %% --------------------------------------------------------------------
    [strike1, dip1, rake1, strike2, dip2, rake2] = ...
        conjugate_solutions(strike, dip, rake);

    % ensure row vectors for consistency
    strike1 = strike1'; 
    dip1    = dip1';    
    rake1   = rake1';
    strike2 = strike2'; 
    dip2    = dip2';    
    rake2   = rake2';
end